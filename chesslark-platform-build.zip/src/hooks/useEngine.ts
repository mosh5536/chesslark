import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

export type EngineInfo = {
  depth?: number;
  nodes?: number;
  nps?: number;
  pv?: string;
  scoreCp?: number;
  scoreMate?: number;
  multipv?: number;
};

export type EngineLine = {
  multipv: number;
  depth?: number;
  scoreCp?: number;
  scoreMate?: number;
  pv?: string;
};

export type EngineState = {
  ready: boolean;
  thinking: boolean;
  bestMoveUci: string | null;
  info: EngineInfo | null;
  evalCp: number | null;
  evalMate: number | null;
  lines: EngineLine[];
  error: string | null;
};

// Fast depth for instant feedback
const DEFAULT_DEPTH = 12;
const DEFAULT_MULTIPV = 3;

function scoreToWhitePov(
  scoreCp: number | undefined,
  scoreMate: number | undefined,
  turn: 'w' | 'b'
): { cp: number | null; mate: number | null } {
  // Stockfish returns score from current player's perspective
  // We need to convert to White's perspective
  const invert = turn === 'b';

  if (typeof scoreMate === 'number') {
    const mate = invert ? -scoreMate : scoreMate;
    return { cp: null, mate };
  }
  
  if (typeof scoreCp === 'number') {
    const cp = invert ? -scoreCp : scoreCp;
    return { cp, mate: null };
  }
  
  return { cp: null, mate: null };
}

export function formatEval(cp: number | null, mate: number | null): string {
  if (typeof mate === 'number') {
    return mate > 0 ? `#${mate}` : `#${mate}`;
  }
  if (typeof cp === 'number') {
    const val = (cp / 100).toFixed(1);
    return cp >= 0 ? `+${val}` : val;
  }
  return '0.0';
}

function getTurnFromFen(fen: string): 'w' | 'b' {
  const parts = fen.split(' ');
  return parts[1] === 'b' ? 'b' : 'w';
}

// Parse UCI info line
function parseInfoLine(line: string): EngineInfo | null {
  if (!line.startsWith('info') || line.includes('currmove')) return null;
  
  const info: EngineInfo = {};
  const parts = line.split(' ');
  
  for (let i = 0; i < parts.length; i++) {
    const key = parts[i];
    const val = parts[i + 1];
    
    switch (key) {
      case 'depth':
        info.depth = parseInt(val, 10);
        break;
      case 'nodes':
        info.nodes = parseInt(val, 10);
        break;
      case 'nps':
        info.nps = parseInt(val, 10);
        break;
      case 'multipv':
        info.multipv = parseInt(val, 10);
        break;
      case 'score':
        if (val === 'cp') {
          info.scoreCp = parseInt(parts[i + 2], 10);
        } else if (val === 'mate') {
          info.scoreMate = parseInt(parts[i + 2], 10);
        }
        break;
      case 'pv':
        info.pv = parts.slice(i + 1).join(' ');
        i = parts.length; // Exit loop
        break;
    }
  }
  
  return info.depth ? info : null;
}

// Parse bestmove line
function parseBestMove(line: string): string | null {
  if (!line.startsWith('bestmove')) return null;
  const parts = line.split(' ');
  return parts[1] || null;
}

export default function useEngine(options?: {
  depth?: number;
  multipv?: number;
}) {
  const depth = options?.depth ?? DEFAULT_DEPTH;
  const multipv = options?.multipv ?? DEFAULT_MULTIPV;

  const workerRef = useRef<Worker | null>(null);
  const lastTurnRef = useRef<'w' | 'b'>('w');
  const isReadyRef = useRef(false);
  const pendingFenRef = useRef<string | null>(null);

  const [state, setState] = useState<EngineState>({
    ready: false,
    thinking: false,
    bestMoveUci: null,
    info: null,
    evalCp: null,
    evalMate: null,
    lines: [],
    error: null,
  });

  // Send command to engine
  const sendCommand = useCallback((cmd: string) => {
    if (workerRef.current) {
      workerRef.current.postMessage(cmd);
    }
  }, []);

  // Initialize worker - load stockfish.js directly as worker
  useEffect(() => {
    if (typeof Worker === 'undefined') {
      setState(s => ({ ...s, error: 'Web Workers not supported' }));
      return;
    }

    let worker: Worker | null = null;
    let initTimeout: ReturnType<typeof setTimeout>;
    
    const initWorker = () => {
      try {
        // Load stockfish-18.js directly as a Web Worker
        // The file must be in public/ folder and served as-is
        worker = new Worker('/stockfish-18.js');
        workerRef.current = worker;

        let uciOkReceived = false;
        // readyOk tracked via isReadyRef

        worker.onmessage = (e: MessageEvent) => {
          const line = typeof e.data === 'string' ? e.data : e.data?.toString?.() || '';
          
          // Handle UCI initialization
          if (line === 'uciok') {
            uciOkReceived = true;
            // Configure engine for speed
            worker?.postMessage('setoption name MultiPV value ' + multipv);
            worker?.postMessage('setoption name Threads value 1');
            worker?.postMessage('setoption name Hash value 16');
            worker?.postMessage('isready');
            return;
          }
          
          if (line === 'readyok') {
            isReadyRef.current = true;
            setState(s => ({ ...s, ready: true, error: null }));
            
            // If there's a pending analysis, run it now
            if (pendingFenRef.current) {
              const fen = pendingFenRef.current;
              pendingFenRef.current = null;
              lastTurnRef.current = getTurnFromFen(fen);
              worker?.postMessage('stop');
              worker?.postMessage('position fen ' + fen);
              worker?.postMessage('go depth ' + depth);
              setState(s => ({ ...s, thinking: true, lines: [] }));
            }
            return;
          }
          
          // Parse info lines
          if (line.startsWith('info')) {
            const info = parseInfoLine(line);
            if (info) {
              const { cp, mate } = scoreToWhitePov(
                info.scoreCp,
                info.scoreMate,
                lastTurnRef.current
              );
              const pvIndex = info.multipv ?? 1;

              setState(s => {
                const lines = [...s.lines];
                const existingIdx = lines.findIndex(l => l.multipv === pvIndex);
                
                const lineData: EngineLine = {
                  multipv: pvIndex,
                  depth: info.depth,
                  scoreCp: info.scoreCp,
                  scoreMate: info.scoreMate,
                  pv: info.pv,
                };

                if (existingIdx >= 0) {
                  lines[existingIdx] = lineData;
                } else {
                  lines.push(lineData);
                }
                lines.sort((a, b) => a.multipv - b.multipv);

                const isMainLine = pvIndex === 1 || !info.multipv;
                
                return {
                  ...s,
                  thinking: true,
                  info: isMainLine ? info : s.info,
                  evalCp: isMainLine ? cp : s.evalCp,
                  evalMate: isMainLine ? mate : s.evalMate,
                  lines,
                };
              });
            }
            return;
          }
          
          // Parse bestmove
          if (line.startsWith('bestmove')) {
            const bestMove = parseBestMove(line);
            setState(s => ({
              ...s,
              thinking: false,
              bestMoveUci: bestMove,
            }));
            return;
          }
        };

        worker.onerror = (err) => {
          console.error('Stockfish worker error:', err);
          setState(s => ({
            ...s,
            ready: false,
            error: 'Engine failed to load. Check console for details.',
          }));
        };

        // Start UCI handshake
        worker.postMessage('uci');
        
        // Timeout if engine doesn't respond
        initTimeout = setTimeout(() => {
          if (!uciOkReceived) {
            setState(s => ({ ...s, error: 'Engine timeout - no UCI response' }));
          }
        }, 5000);

      } catch (err) {
        console.error('Failed to create worker:', err);
        setState(s => ({
          ...s,
          error: `Failed to load engine: ${err instanceof Error ? err.message : 'Unknown error'}`,
        }));
      }
    };

    initWorker();

    return () => {
      clearTimeout(initTimeout);
      if (worker) {
        worker.postMessage('quit');
        worker.terminate();
      }
      workerRef.current = null;
      isReadyRef.current = false;
    };
  }, [depth, multipv]);

  // Analyze a position
  const analyze = useCallback((fen: string) => {
    if (!workerRef.current) return;
    
    // If not ready yet, queue the analysis
    if (!isReadyRef.current) {
      pendingFenRef.current = fen;
      return;
    }

    lastTurnRef.current = getTurnFromFen(fen);
    
    // Stop any current analysis and start new one
    workerRef.current.postMessage('stop');
    workerRef.current.postMessage('position fen ' + fen);
    workerRef.current.postMessage('go depth ' + depth);
    
    setState(s => ({
      ...s,
      thinking: true,
      bestMoveUci: null,
      lines: [],
    }));
  }, [depth]);

  // Stop current analysis
  const stop = useCallback(() => {
    if (workerRef.current) {
      workerRef.current.postMessage('stop');
      setState(s => ({ ...s, thinking: false }));
    }
  }, []);

  // New game - reset position
  const newGame = useCallback(() => {
    if (workerRef.current) {
      workerRef.current.postMessage('stop');
      workerRef.current.postMessage('ucinewgame');
      workerRef.current.postMessage('isready');
    }
    setState(s => ({
      ...s,
      thinking: false,
      bestMoveUci: null,
      info: null,
      evalCp: null,
      evalMate: null,
      lines: [],
    }));
  }, []);

  // Format evaluation for display
  const evalDisplay = useMemo(() => {
    return formatEval(state.evalCp, state.evalMate);
  }, [state.evalCp, state.evalMate]);

  // Calculate eval bar percentage (0-100, from White's perspective)
  const evalBarPercent = useMemo(() => {
    if (state.evalMate !== null) {
      // Mate: show extreme advantage
      return state.evalMate > 0 ? 95 : 5;
    }
    if (state.evalCp !== null) {
      // Sigmoid-like function: clamp to reasonable range
      // +300cp = ~75%, -300cp = ~25%, 0 = 50%
      const clamped = Math.max(-600, Math.min(600, state.evalCp));
      const percent = 50 + (clamped / 600) * 45;
      return Math.max(2, Math.min(98, percent));
    }
    return 50; // Unknown = equal
  }, [state.evalCp, state.evalMate]);

  return {
    ...state,
    analyze,
    stop,
    newGame,
    evalDisplay,
    evalBarPercent,
    sendCommand,
  };
}
